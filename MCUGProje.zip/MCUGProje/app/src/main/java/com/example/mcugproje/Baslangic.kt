package com.example.mcugproje

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast

class Baslangic : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_baslangic)
        val text1 = findViewById(R.id.text1) as TextView
        val text2 = findViewById(R.id.text2) as TextView
        val text3 = findViewById(R.id.text3) as TextView
        val text4 = findViewById(R.id.text4) as TextView
        val text5 = findViewById(R.id.text5) as TextView

        val tik1 = findViewById(R.id.tik1) as ImageView
        val tik2 = findViewById(R.id.tik2) as ImageView
        val tik3 = findViewById(R.id.tik3) as ImageView
        val tik4 = findViewById(R.id.tik4) as ImageView
        val tik5 = findViewById(R.id.tik5) as ImageView

        val progressBar = findViewById(R.id.progressBar) as ProgressBar
        val dizi: Array<Int> = arrayOf(0, 0, 0, 0)

        tik1.setVisibility(View.INVISIBLE)
        tik2.setVisibility(View.INVISIBLE)
        tik3.setVisibility(View.INVISIBLE)
        tik4.setVisibility(View.INVISIBLE)
        tik5.setVisibility(View.INVISIBLE)

        progressBar.visibility = View.INVISIBLE
// set on-click listener
        text1.setOnClickListener {
            tik1.setVisibility(View.VISIBLE)
            dizi[0] = 1
            text2.setOnClickListener {
                if (dizi[0] == 1) {
                    tik2.setVisibility(View.VISIBLE)
                    dizi[1] = 1
                }
            }
            text3.setOnClickListener {
                if (dizi[1] == 1) {
                    tik3.setVisibility(View.VISIBLE)
                    dizi[2] = 1
                }
            }
            text4.setOnClickListener {
                if (dizi[2] == 1) {
                    tik4.setVisibility(View.VISIBLE)
                    dizi[3] = 1
                }
            }
            text5.setOnClickListener {
                if (dizi[3] == 1) {
                    tik5.setVisibility(View.VISIBLE)
                    progressBar.visibility = View.VISIBLE
                    Handler().postDelayed({
                        var gecis = Intent(this, Corba::class.java)
                        startActivity(gecis)
                        finish()
                    }, 2000)
                }
            }
        }
    }
}
