package com.example.mcugproje

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.Intent
import android.view.View
import android.widget.Button
import android.widget.RadioButton
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import androidx.appcompat.app.AlertDialog

class CorbaSecim : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.corbasecim)
        val text=findViewById(R.id.ekstratest) as TextView
        var corbaAktarim = Array<Int>(12){0}
        val Aktarim = intent.getStringExtra("CorbaAktarim")

        val tuzbar = findViewById(R.id.tuzbar) as SeekBar
        val acibar = findViewById(R.id.acibar) as SeekBar

        val secimtasima = StringBuilder()
        var secimtasimav1 = String()
        var secimtasimatext = String()

        val switch1 = findViewById(R.id.switch1) as Switch
        val switch2 = findViewById(R.id.switch2) as Switch
        val switch3 = findViewById(R.id.switch3) as Switch
        val switch4 = findViewById(R.id.switch4) as Switch
        val switch5 = findViewById(R.id.switch5) as Switch
        val switch6 = findViewById(R.id.switch6) as Switch
        val switch7 = findViewById(R.id.switch7) as Switch
        val switch8 = findViewById(R.id.switch8) as Switch
        val switch9 = findViewById(R.id.switch9) as Switch
        val switch10 = findViewById(R.id.switch10) as Switch
        val switch11 = findViewById(R.id.switch11) as Switch
        val switch12 = findViewById(R.id.switch12) as Switch

        val sbutton = findViewById(R.id.siparisbutton) as Button
        val gettext = findViewById(R.id.ekstratest) as TextView
        val text1 = findViewById(R.id.maintext) as TextView
        text1.setText("$Aktarim Corbasi")

        if (Aktarim=="Ezogelin"){
            corbaAktarim[0]=0;corbaAktarim[1]=1;corbaAktarim[2]=0
            corbaAktarim[3]=0;corbaAktarim[4]=0;corbaAktarim[5]=0
            corbaAktarim[6]=0;corbaAktarim[7]=1;corbaAktarim[8]=0
            corbaAktarim[9]=1;corbaAktarim[10]=1;corbaAktarim[11]=1
        }else if (Aktarim=="Dugun"){
            corbaAktarim[0]=0;corbaAktarim[1]=1;corbaAktarim[2]=0
            corbaAktarim[3]=0;corbaAktarim[4]=0;corbaAktarim[5]=0
            corbaAktarim[6]=0;corbaAktarim[7]=1;corbaAktarim[8]=0
            corbaAktarim[9]=1;corbaAktarim[10]=1;corbaAktarim[11]=1
        }else if (Aktarim=="Mercimek"){
            corbaAktarim[0]=0;corbaAktarim[1]=1;corbaAktarim[2]=0
            corbaAktarim[3]=0;corbaAktarim[4]=0;corbaAktarim[5]=0
            corbaAktarim[6]=0;corbaAktarim[7]=1;corbaAktarim[8]=0
            corbaAktarim[9]=1;corbaAktarim[10]=1;corbaAktarim[11]=1
        }
        else if (Aktarim=="Brokoli"){
            corbaAktarim[0]=0;corbaAktarim[1]=0;corbaAktarim[2]=0
            corbaAktarim[3]=0;corbaAktarim[4]=0;corbaAktarim[5]=0
            corbaAktarim[6]=1;corbaAktarim[7]=0;corbaAktarim[8]=0
            corbaAktarim[9]=0;corbaAktarim[10]=0;corbaAktarim[11]=0
        }
        else if (Aktarim=="Kelle-Paca"){
            corbaAktarim[0]=1;corbaAktarim[1]=0;corbaAktarim[2]=1
            corbaAktarim[3]=0;corbaAktarim[4]=1;corbaAktarim[5]=1
            corbaAktarim[6]=0;corbaAktarim[7]=1;corbaAktarim[8]=0
            corbaAktarim[9]=0;corbaAktarim[10]=1;corbaAktarim[11]=0
        }
        else if (Aktarim=="Yayla"){
            corbaAktarim[0]=0;corbaAktarim[1]=1;corbaAktarim[2]=0
            corbaAktarim[3]=0;corbaAktarim[4]=0;corbaAktarim[5]=0
            corbaAktarim[6]=0;corbaAktarim[7]=1;corbaAktarim[8]=0
            corbaAktarim[9]=1;corbaAktarim[10]=0;corbaAktarim[11]=1
        }
        else if (Aktarim=="Sehriye"){
            corbaAktarim[0]=0;corbaAktarim[1]=1;corbaAktarim[2]=0
            corbaAktarim[3]=0;corbaAktarim[4]=0;corbaAktarim[5]=0
            corbaAktarim[6]=0;corbaAktarim[7]=1;corbaAktarim[8]=0
            corbaAktarim[9]=0;corbaAktarim[10]=1;corbaAktarim[11]=1
        }
        else if (Aktarim=="Domates"){
            corbaAktarim[0]=0;corbaAktarim[1]=1;corbaAktarim[2]=0
            corbaAktarim[3]=1;corbaAktarim[4]=0;corbaAktarim[5]=0
            corbaAktarim[6]=0;corbaAktarim[7]=1;corbaAktarim[8]=1
            corbaAktarim[9]=1;corbaAktarim[10]=1;corbaAktarim[11]=1
        }
        else if (Aktarim=="Tarhana"){
            corbaAktarim[0]=0;corbaAktarim[1]=0;corbaAktarim[2]=0
            corbaAktarim[3]=0;corbaAktarim[4]=0;corbaAktarim[5]=0
            corbaAktarim[6]=0;corbaAktarim[7]=1;corbaAktarim[8]=0
            corbaAktarim[9]=0;corbaAktarim[10]=0;corbaAktarim[11]=1
        }
        else if (Aktarim=="Mantar"){
            corbaAktarim[0]=0;corbaAktarim[1]=0;corbaAktarim[2]=0
            corbaAktarim[3]=0;corbaAktarim[4]=0;corbaAktarim[5]=0
            corbaAktarim[6]=1;corbaAktarim[7]=0;corbaAktarim[8]=0
            corbaAktarim[9]=0;corbaAktarim[10]=0;corbaAktarim[11]=0
        }
        else if (Aktarim=="Iskembe"){
            corbaAktarim[0]=1;corbaAktarim[1]=0;corbaAktarim[2]=0
            corbaAktarim[3]=0;corbaAktarim[4]=0;corbaAktarim[5]=1
            corbaAktarim[6]=0;corbaAktarim[7]=1;corbaAktarim[8]=0
            corbaAktarim[9]=0;corbaAktarim[10]=1;corbaAktarim[11]=1
        }
        else if (Aktarim=="Tavuk"){
            corbaAktarim[0]=0;corbaAktarim[1]=0;corbaAktarim[2]=0
            corbaAktarim[3]=0;corbaAktarim[4]=0;corbaAktarim[5]=0
            corbaAktarim[6]=1;corbaAktarim[7]=1;corbaAktarim[8]=0
            corbaAktarim[9]=0;corbaAktarim[10]=1;corbaAktarim[11]=0
        }
        if (corbaAktarim[0]==0){ switch1.setVisibility(View.INVISIBLE)
        }else{ switch1.setVisibility(View.VISIBLE) }

        if (corbaAktarim[1]==0){ switch2.setVisibility(View.INVISIBLE)
        }else{ switch2.setVisibility(View.VISIBLE) }

        if (corbaAktarim[2]==0){ switch3.setVisibility(View.INVISIBLE)
        }else{ switch3.setVisibility(View.VISIBLE) }

        if (corbaAktarim[3]==0){ switch4.setVisibility(View.INVISIBLE)
        }else{ switch4.setVisibility(View.VISIBLE) }

        if (corbaAktarim[4]==0){ switch5.setVisibility(View.INVISIBLE)
        }else{ switch5.setVisibility(View.VISIBLE) }

        if (corbaAktarim[5]==0){ switch6.setVisibility(View.INVISIBLE)
        }else{ switch6.setVisibility(View.VISIBLE) }

        if (corbaAktarim[6]==0){ switch7.setVisibility(View.INVISIBLE)
        }else{ switch7.setVisibility(View.VISIBLE) }

        if (corbaAktarim[7]==0){ switch8.setVisibility(View.INVISIBLE)
        }else{ switch8.setVisibility(View.VISIBLE) }

        if (corbaAktarim[8]==0){ switch9.setVisibility(View.INVISIBLE)
        }else{ switch9.setVisibility(View.VISIBLE) }

        if (corbaAktarim[9]==0){ switch10.setVisibility(View.INVISIBLE)
        }else{ switch10.setVisibility(View.VISIBLE) }

        if (corbaAktarim[10]==0){ switch11.setVisibility(View.INVISIBLE)
        }else{ switch11.setVisibility(View.VISIBLE) }

        if (corbaAktarim[11]==0){ switch12.setVisibility(View.INVISIBLE)
        }else{ switch12.setVisibility(View.VISIBLE) }

        tuzbar.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener{
            override fun onProgressChanged(p0: SeekBar?, p1: Int, p2: Boolean) {
                if (p1==2){
                    val uyari = AlertDialog.Builder(this@CorbaSecim)
                    uyari.setTitle("Uyari!")
                    uyari.setMessage("Bu kadar tuz istedigine emin misin?")
                    uyari.setPositiveButton("Evet"){DialogInterface, i->
                    }
                    uyari.setNegativeButton("Hayir"){DialogInterface, i->
                        tuzbar.setProgress(1)
                    }
                    uyari.create().show()
                }
            }
            override fun onStartTrackingTouch(p0: SeekBar?) {}
            override fun onStopTrackingTouch(p0: SeekBar?) {}
        })
        acibar.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener{
            override fun onProgressChanged(p0: SeekBar?, p1: Int, p2: Boolean) {
                if (p1==2){
                    val uyari1 = AlertDialog.Builder(this@CorbaSecim)
                    uyari1.setTitle("Uyari!")
                    uyari1.setMessage("Bu kadar aci istedigine emin misin?")
                    uyari1.setPositiveButton("Evet"){DialogInterface, i->
                    }
                    uyari1.setNegativeButton("Hayir"){DialogInterface, i->
                        acibar.setProgress(1)
                    }
                    uyari1.create().show()
                }
            }
            override fun onStartTrackingTouch(p0: SeekBar?) {}
            override fun onStopTrackingTouch(p0: SeekBar?) {}
        })
        sbutton.setOnClickListener{
            if(tuzbar.progress==0){
                secimtasima.append("0")
            }else if (tuzbar.progress==1){
                secimtasima.append("1")
            }else{
                secimtasima.append("2") }

            if(acibar.progress==0){
                secimtasima.append("0")
            }else if (acibar.progress==1){
                secimtasima.append("1")
            }else{
                secimtasima.append("2") }
            if (switch1.isChecked==true){
                secimtasima.append("1")
            }else{
                secimtasima.append("0")
            }
            if (switch2.isChecked==true){
                secimtasima.append("1")
            }else{
                secimtasima.append("0")
            }
            if (switch3.isChecked==true){
                secimtasima.append("1")
            }else{
                secimtasima.append("0")
            }
            if (switch4.isChecked==true){
                secimtasima.append("1")
            }else{
                secimtasima.append("0")
            }
            if (switch5.isChecked==true){
                secimtasima.append("1")
            }else{
                secimtasima.append("0")
            }
            if (switch6.isChecked==true){
                secimtasima.append("1")
            }else{
                secimtasima.append("0")
            }
            if (switch7.isChecked==true){
                secimtasima.append("1")
            }else{
                secimtasima.append("0")
            }
            if (switch8.isChecked==true){
                secimtasima.append("1")
            }else{
                secimtasima.append("0")
            }
            if (switch9.isChecked==true){
                secimtasima.append("1")
            }else{
                secimtasima.append("0")
            }
            if (switch10.isChecked==true){
                secimtasima.append("1")
            }else{
                secimtasima.append("0")
            }
            if (switch11.isChecked==true){
                secimtasima.append("1")
            }else{
                secimtasima.append("0")
            }
            if (switch12.isChecked==true){
                secimtasima.append("1")
            }else{
                secimtasima.append("0")
            }
            secimtasimatext=gettext.text.toString()

            val uyari2 = AlertDialog.Builder(this)
            uyari2.setTitle("Siparis Durumunuz")
            uyari2.setMessage("Siparisiniz hazirlanacak. Devam etmek istiyor musunuz?")
            uyari2.setIcon(R.drawable.ssimage)
            uyari2.setPositiveButton("Evet"){DialogInterface, i->
                secimtasimav1=secimtasima.toString()
                val intent = Intent(this@CorbaSecim,Siparis::class.java)
                intent.putExtra("SecimTasima", secimtasimav1)
                intent.putExtra("Corbatur",Aktarim)
                intent.putExtra("SecimTasimaText", secimtasimatext)
                startActivity(intent)
                finish()
            }
            uyari2.setNegativeButton("TEKRAR KONTROL ETMEK ISTIYORUM"){DialogInterface, i->
            }
            uyari2.create().show()
        }
    }
}