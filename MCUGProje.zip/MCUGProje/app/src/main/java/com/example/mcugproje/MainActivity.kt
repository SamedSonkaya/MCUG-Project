package com.example.mcugproje

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.view.View
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val text = findViewById(R.id.sstext) as TextView

        Handler().postDelayed({
            val intent = Intent(this@MainActivity,Baslangic::class.java)
            startActivity(intent)
            finish()
        }, 5000)
    }
}