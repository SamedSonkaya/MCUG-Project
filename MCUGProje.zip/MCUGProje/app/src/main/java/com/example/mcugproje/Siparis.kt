package com.example.mcugproje

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.core.os.postDelayed
import kotlinx.coroutines.delay
import java.util.concurrent.Delayed
import kotlin.system.exitProcess

class Siparis : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_siparis)

        val toptext = findViewById(R.id.toptext) as TextView
        val midtext = findViewById(R.id.midtext) as TextView
        val bottext = findViewById(R.id.bottext) as TextView
        val siparistext = findViewById(R.id.siparistext) as TextView
        val exittext = findViewById(R.id.exittext) as ImageView

        val Corbatur = intent.getStringExtra("Corbatur")
        val secimtasima = intent.getStringExtra("SecimTasima")
        val secimtasimatext = intent.getStringExtra("SecimTasimaText")
        val secim = StringBuilder()
        val secimtuzaci = StringBuilder()
        var textnum=13
        if (secimtasima != null) {
            for (x in secimtasima.iterator()){
                if (textnum==0){
                    if (x=='1'){
                        secim.append("Toz Biber, ")
                    }
                }
                if(textnum==1){
                    if(x=='1'){
                        secim.append("Limon, ")
                    }
                }
                if(textnum==2){
                    if(x=='1'){
                        secim.append("Kitir, ")
                    }
                }
                if(textnum==3){
                    if(x=='1'){
                        secim.append("Kasar, ")
                    }
                }
                if(textnum==4){
                    if(x=='1'){
                        secim.append("Yag, ")
                    }
                }
                if(textnum==5){
                    if(x=='1'){
                        secim.append("Krema, ")
                    }
                }
                if(textnum==6){
                    if(x=='1'){
                        secim.append("Sirke, ")
                    }
                }
                if(textnum==7){
                    if(x=='1'){
                        secim.append("Beyin, ")
                    }
                }
                if(textnum==8){
                    if(x=='1'){
                        secim.append("Terbiye, ")
                    }
                }
                if(textnum==9){
                    if(x=='1'){
                        secim.append("Dil, ")
                    }
                }
                if(textnum==10){
                    if(x=='1'){
                        secim.append("Nane, ")
                    }
                }
                if(textnum==11){
                    if(x=='1'){
                        secim.append("Sarimsak, ")
                    }
                }
                if(textnum==12){
                    if(x=='2'){
                        secimtuzaci.append("Bol Acili")
                    }else if(x=='1'){
                        secimtuzaci.append("Acili")
                    }else{
                        secimtuzaci.append("Acisiz")
                    }
                }
                if(textnum==13){
                    if(x=='2'){
                        secimtuzaci.append("Bol Tuzlu, ")
                    }else if(x=='1'){
                        secimtuzaci.append("Tuzlu, ")
                    }else{
                        secimtuzaci.append("Tuzsuz, ")
                    }
                }
                textnum -= 1
            }
        }
        toptext.setText("Bir $Corbatur Corbasi Ceek, $secimtuzaci")
        midtext.setText("$secim")
        bottext.setText("Ekstra Istek : $secimtasimatext")
        for(x in 1..3){
            Handler().postDelayed({
                siparistext.visibility= View.INVISIBLE
            }, 1000)
            Handler().postDelayed({
                siparistext.visibility= View.VISIBLE
            }, 1000)
        }
        siparistext.setOnClickListener{
            val intent = Intent(this@Siparis,Corba::class.java)
            startActivity(intent)
        }
        exittext.setOnClickListener{
            val uyari = AlertDialog.Builder(this)
            uyari.setTitle("Cikis")
            uyari.setIcon(R.drawable.exit)
            uyari.setMessage("Cikmak Istediginize Emin misiniz?")
            uyari.setPositiveButton("Evet"){DialogInterface, i->
                exitProcess(0)
            }
            uyari.setNegativeButton("Hayir"){DialogInterface, i->}
            uyari.create().show()
        }
    }
}