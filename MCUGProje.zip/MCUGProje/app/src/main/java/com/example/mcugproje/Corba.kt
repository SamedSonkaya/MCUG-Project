package com.example.mcugproje

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog

class Corba : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_corba)

        var ch = findViewById<CheckBox>(R.id.corbabox)
        var rg = findViewById<RadioGroup>(R.id.radioGroup)
        var cb = findViewById<Button>(R.id.corbabutton)

        var corbatur = String()

        var rb1 = findViewById<RadioButton>(R.id.radioButton1)
        var rb2 = findViewById<RadioButton>(R.id.radioButton2)
        var rb3 = findViewById<RadioButton>(R.id.radioButton3)
        var rb4 = findViewById<RadioButton>(R.id.radioButton4)
        var rb5 = findViewById<RadioButton>(R.id.radioButton5)
        var rb6 = findViewById<RadioButton>(R.id.radioButton6)
        var rb7 = findViewById<RadioButton>(R.id.radioButton7)
        var rb8 = findViewById<RadioButton>(R.id.radioButton8)
        var rb9 = findViewById<RadioButton>(R.id.radioButton9)
        var rb10 = findViewById<RadioButton>(R.id.radioButton10)
        var rb11 = findViewById<RadioButton>(R.id.radioButton11)
        var rb12 = findViewById<RadioButton>(R.id.radioButton12)


        cb.setVisibility(View.INVISIBLE)
        rg.setVisibility(View.INVISIBLE)

        ch.setOnClickListener{
            if (ch.isChecked == true){
                cb.setVisibility(View.VISIBLE)
                rg.setVisibility(View.VISIBLE)
            }
        }
        rb1.setOnClickListener{
            if (rb1.isChecked== true){
                corbatur="Ezogelin"}}

        rb2.setOnClickListener{
            if (rb2.isChecked== true){
                corbatur="Dugun"}}

        rb3.setOnClickListener{
            if (rb3.isChecked== true){
                corbatur="Mercimek"}}

        rb4.setOnClickListener{
            if (rb4.isChecked== true){
                corbatur="Brokoli"}}

        rb5.setOnClickListener{
            if (rb5.isChecked== true){
                corbatur="Kelle-Paca"}}

        rb6.setOnClickListener{
            if (rb6.isChecked== true){
                corbatur="Yayla"}}

        rb7.setOnClickListener{
            if (rb7.isChecked== true){
                corbatur="Sehriye"}}

        rb8.setOnClickListener{
            if (rb8.isChecked== true){
                corbatur="Domates"}}

        rb9.setOnClickListener{
            if (rb9.isChecked== true){
                corbatur="Tarhana" }}

        rb10.setOnClickListener{
            if (rb10.isChecked== true){
                corbatur="Mantar" }}

        rb11.setOnClickListener{
            if (rb11.isChecked== true){
                corbatur="Iskembe" }}

        rb12.setOnClickListener{
            if (rb12.isChecked== true){
                corbatur="Tavuk" }}

        cb.setOnClickListener {
            if (corbatur==""){
                val uyari = AlertDialog.Builder(this)
                uyari.setTitle("Uyari!!!")
                uyari.setMessage("Lutfen bir corba seciniz")
                uyari.setPositiveButton("Tamam"){DialogInterface, i->
                }
                uyari.create().show()
            }else{
                var Inftoast = layoutInflater.inflate(R.layout.toastfile,null)
                var contost = Toast(applicationContext)
                var toasttext =Inftoast.findViewById<TextView>(R.id.toasttext)
                toasttext.text="$corbatur Corbasi guzel secim lutfen bekleyiniz"
                contost.view = Inftoast
                contost.setGravity(Gravity.BOTTOM,150,0)
                contost.duration=Toast.LENGTH_SHORT
                contost.show()

                Handler().postDelayed({
                    val intent = Intent(this@Corba,CorbaSecim::class.java)
                    intent.putExtra("CorbaAktarim", corbatur)
                    startActivity(intent)
                    finish()
                }, 3000)
            }
        }
    }
}